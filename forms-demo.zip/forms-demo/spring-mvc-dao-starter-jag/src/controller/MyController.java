package controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import model.Vehicle;
import model.VehicleService;

@Controller
public class MyController 
{
	@Autowired
	VehicleService vs;
	
//	@RequestMapping("/")
//	public String show(ModelMap modelMap)
//	{		
//		List<Vehicle> vehicles = vs.read();
//		Vehicle vehicle = vs.read(147);
//		modelMap.addAttribute("vehicles", vehicles);
//		modelMap.addAttribute("vehicle",vehicle);
//		return "vehicle";
//	}
//	
//	@RequestMapping("/select")
//	public String select(@RequestParam("id") int id, ModelMap modelMap)
//	{
//		List<Vehicle> vehicles = vs.read();
//		Vehicle vehicle = vs.read(id);
//		modelMap.addAttribute("vehicle",vehicle);
//		modelMap.addAttribute("vehicles", vehicles);
//		return "vehicle";
//	}
//	
//	@RequestMapping(method = RequestMethod.POST, value = "/add")
//	public String addVehicle(@ModelAttribute("vehicle") Vehicle vehicle, ModelMap modelMap) 
//	{
//		System.out.println("controller: add method: "+vehicle);
//		vehicle.setId(0);
//		vs.add(vehicle);
//		return show(modelMap);
//	}
}
